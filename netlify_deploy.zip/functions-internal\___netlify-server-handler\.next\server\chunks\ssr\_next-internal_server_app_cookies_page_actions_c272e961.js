module.exports=[20883,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_cookies_page_actions_c272e961.js.map