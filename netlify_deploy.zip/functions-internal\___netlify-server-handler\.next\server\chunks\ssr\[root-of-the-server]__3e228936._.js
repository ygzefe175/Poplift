module.exports=[18622,(a,b,c)=>{b.exports=a.x("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js",()=>require("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js"))},42602,(a,b,c)=>{"use strict";b.exports=a.r(18622)},87924,(a,b,c)=>{"use strict";b.exports=a.r(42602).vendored["react-ssr"].ReactJsxRuntime},72131,(a,b,c)=>{"use strict";b.exports=a.r(42602).vendored["react-ssr"].React},9270,(a,b,c)=>{"use strict";b.exports=a.r(42602).vendored.contexts.AppRouterContext},38783,(a,b,c)=>{"use strict";b.exports=a.r(42602).vendored["react-ssr"].ReactServerDOMTurbopackClient},52495,a=>{"use strict";let b=(0,a.i(70106).default)("external-link",[["path",{d:"M15 3h6v6",key:"1q9fwt"}],["path",{d:"M10 14 21 3",key:"gplh6r"}],["path",{d:"M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6",key:"a6xqqp"}]]);a.s(["ExternalLink",()=>b],52495)},69520,a=>{"use strict";let b=(0,a.i(70106).default)("refresh-cw",[["path",{d:"M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8",key:"v9h5vc"}],["path",{d:"M21 3v5h-5",key:"1q7to0"}],["path",{d:"M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16",key:"3uifl3"}],["path",{d:"M8 16H3v5",key:"1cv678"}]]);a.s(["RefreshCw",()=>b],69520)},20828,a=>{"use strict";var b=a.i(87924),c=a.i(72131),d=a.i(32636),e=a.i(70106);let f=(0,e.default)("arrow-left",[["path",{d:"m12 19-7-7 7-7",key:"1l729n"}],["path",{d:"M19 12H5",key:"x3x0zl"}]]);var g=a.i(52495);let h=(0,e.default)("play",[["path",{d:"M5 5a2 2 0 0 1 3.008-1.728l11.997 6.998a2 2 0 0 1 .003 3.458l-12 7A2 2 0 0 1 5 19z",key:"10ikf1"}]]);var i=a.i(69520),j=a.i(38246);function k(){let{user:a}=(0,d.useAuth)(),[e,k]=(0,c.useState)(0),[l,m]=(0,c.useState)("");(0,c.useEffect)(()=>{m(window.location.origin)},[]);let n=`
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Test Sitesi - Popwise Demo</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { 
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            color: white;
        }
        .container { max-width: 800px; margin: 0 auto; padding: 40px 20px; }
        h1 { font-size: 2.5rem; margin-bottom: 1rem; }
        p { font-size: 1.1rem; opacity: 0.9; line-height: 1.6; margin-bottom: 1rem; }
        .card { 
            background: rgba(255,255,255,0.1); 
            backdrop-filter: blur(10px);
            border-radius: 16px; 
            padding: 24px; 
            margin: 20px 0;
            border: 1px solid rgba(255,255,255,0.2);
        }
        .btn {
            background: white;
            color: #764ba2;
            padding: 12px 24px;
            border: none;
            border-radius: 8px;
            font-weight: 600;
            cursor: pointer;
            margin-top: 20px;
        }
        .notice {
            background: rgba(0,0,0,0.2);
            padding: 12px 16px;
            border-radius: 8px;
            font-size: 0.9rem;
            margin-top: 40px;
        }
    </style>
    
    <!-- Popwise Conversion System -->
    <script src="${l}/api/pixel?id=${a?.id||"demo"}" async></script>
</head>
<body>
    <div class="container">
        <h1>🎉 \xd6rnek E-Ticaret Sitesi</h1>
        <p>Bu sayfa, Popwise embed kodunun nasıl \xe7alıştığını test etmek i\xe7in oluşturulmuş bir demo sitedir.</p>
        
        <div class="card">
            <h2>🛍️ \xdcr\xfcnlerimiz</h2>
            <p>En kaliteli \xfcr\xfcnleri en uygun fiyatlarla sunuyoruz. Hemen alışverişe başlayın!</p>
            <button class="btn">Alışverişe Başla</button>
        </div>
        
        <div class="card">
            <h2>📦 Hızlı Teslimat</h2>
            <p>T\xfcm siparişleriniz 24 saat i\xe7inde kargoya verilir. \xdccretsiz kargo fırsatını ka\xe7ırmayın!</p>
        </div>
        
        <div class="card">
            <h2>💳 G\xfcvenli \xd6deme</h2>
            <p>256-bit SSL şifreleme ile g\xfcvenli \xf6deme. Kredi kartı bilgileriniz bizde g\xfcvende.</p>
        </div>
        
        <p style="margin-top: 40px;">Sayfayı kaydırın veya fareyi yukarı \xe7ıkarın (exit intent) pop-up'ları tetiklemek i\xe7in.</p>
        
        <div style="height: 500px;"></div>
        
        <div class="card">
            <h2>📞 İletişim</h2>
            <p>Sorularınız i\xe7in bize ulaşın: info@example.com</p>
        </div>
        
        <div class="notice">
            ⚡ Bu sayfada Popwise embed kodu aktif. Pop-up'larınız burada g\xf6r\xfcnecek!
        </div>
    </div>
</body>
</html>`;return(0,b.jsxs)("main",{className:"min-h-screen bg-[#0a0a0b]",children:[(0,b.jsx)("div",{className:"border-b border-white/10 bg-[#0f1117]",children:(0,b.jsxs)("div",{className:"max-w-7xl mx-auto px-6 py-4 flex items-center justify-between",children:[(0,b.jsxs)("div",{className:"flex items-center gap-4",children:[(0,b.jsxs)(j.default,{href:"/dashboard",className:"flex items-center gap-2 text-slate-400 hover:text-white transition-colors",children:[(0,b.jsx)(f,{size:20}),"Dashboard'a Dön"]}),(0,b.jsx)("span",{className:"text-slate-600",children:"|"}),(0,b.jsx)("h1",{className:"text-white font-bold",children:"Embed Kodu Test Sayfası"})]}),(0,b.jsxs)("div",{className:"flex items-center gap-3",children:[(0,b.jsxs)("button",{onClick:()=>k(a=>a+1),className:"flex items-center gap-2 px-4 py-2 bg-white/10 hover:bg-white/20 text-white rounded-lg transition-colors text-sm font-medium",children:[(0,b.jsx)(i.RefreshCw,{size:16}),"Yenile"]}),(0,b.jsxs)("a",{href:`data:text/html;charset=utf-8,${encodeURIComponent(n)}`,target:"_blank",rel:"noopener noreferrer",className:"flex items-center gap-2 px-4 py-2 bg-brand-orange hover:bg-amber-500 text-black rounded-lg transition-colors text-sm font-bold",children:[(0,b.jsx)(g.ExternalLink,{size:16}),"Yeni Sekmede Aç"]})]})]})}),(0,b.jsx)("div",{className:"bg-emerald-500/10 border-b border-emerald-500/20",children:(0,b.jsxs)("div",{className:"max-w-7xl mx-auto px-6 py-3 flex items-center gap-3",children:[(0,b.jsx)(h,{size:16,className:"text-emerald-500"}),(0,b.jsxs)("p",{className:"text-emerald-400 text-sm",children:[(0,b.jsx)("strong",{children:"Test Modu Aktif:"})," Aşağıdaki iframe'de embed kodunuz çalışıyor. Pop-up tetiklemek için sayfayı kaydırın veya fareyi yukarı çıkarın."]})]})}),(0,b.jsxs)("div",{className:"max-w-7xl mx-auto px-6 py-8",children:[(0,b.jsxs)("div",{className:"bg-[#1c1c1e] rounded-2xl border border-white/10 overflow-hidden shadow-2xl",children:[(0,b.jsxs)("div",{className:"bg-[#2a2a2e] px-4 py-3 flex items-center gap-3 border-b border-white/10",children:[(0,b.jsxs)("div",{className:"flex gap-2",children:[(0,b.jsx)("div",{className:"w-3 h-3 rounded-full bg-red-500"}),(0,b.jsx)("div",{className:"w-3 h-3 rounded-full bg-yellow-500"}),(0,b.jsx)("div",{className:"w-3 h-3 rounded-full bg-green-500"})]}),(0,b.jsx)("div",{className:"flex-1 bg-[#1c1c1e] rounded-lg px-4 py-1.5 text-sm text-slate-400 font-mono",children:"https://ornek-eticaret-sitesi.com"})]}),(0,b.jsx)("iframe",{srcDoc:n,className:"w-full h-[600px] border-0",title:"Embed Test",sandbox:"allow-scripts allow-same-origin"},e)]}),(0,b.jsxs)("div",{className:"mt-8 bg-[#1c1c1e] rounded-2xl border border-white/10 p-6",children:[(0,b.jsx)("h2",{className:"text-white font-bold text-lg mb-4",children:"🔧 Teknik Bilgiler"}),(0,b.jsxs)("div",{className:"grid grid-cols-1 md:grid-cols-2 gap-4",children:[(0,b.jsxs)("div",{className:"bg-black/30 rounded-lg p-4",children:[(0,b.jsx)("p",{className:"text-slate-500 text-xs uppercase tracking-wider mb-1",children:"User ID"}),(0,b.jsx)("p",{className:"text-white font-mono text-sm",children:a?.id||"Giriş yapılmamış"})]}),(0,b.jsxs)("div",{className:"bg-black/30 rounded-lg p-4",children:[(0,b.jsx)("p",{className:"text-slate-500 text-xs uppercase tracking-wider mb-1",children:"Pixel URL"}),(0,b.jsxs)("p",{className:"text-white font-mono text-sm break-all",children:[l,"/api/pixel?id=",a?.id||"demo"]})]}),(0,b.jsxs)("div",{className:"bg-black/30 rounded-lg p-4",children:[(0,b.jsx)("p",{className:"text-slate-500 text-xs uppercase tracking-wider mb-1",children:"Popups API"}),(0,b.jsxs)("p",{className:"text-white font-mono text-sm break-all",children:[l,"/api/popups/",a?.id||"demo"]})]}),(0,b.jsxs)("div",{className:"bg-black/30 rounded-lg p-4",children:[(0,b.jsx)("p",{className:"text-slate-500 text-xs uppercase tracking-wider mb-1",children:"Track API"}),(0,b.jsxs)("p",{className:"text-white font-mono text-sm break-all",children:[l,"/api/track"]})]})]}),(0,b.jsx)("div",{className:"mt-6 p-4 bg-amber-500/10 border border-amber-500/20 rounded-lg",children:(0,b.jsxs)("p",{className:"text-amber-400 text-sm",children:[(0,b.jsx)("strong",{children:"💡 İpucu:"})," Dashboard'dan en az bir aktif pop-up oluşturduğunuzdan emin olun. Sadece ",(0,b.jsx)("code",{className:"bg-black/30 px-1.5 py-0.5 rounded",children:"is_active = true"})," olan pop-up'lar görünür."]})})]})]})]})}a.s(["default",()=>k],20828)}];

//# sourceMappingURL=%5Broot-of-the-server%5D__3e228936._.js.map