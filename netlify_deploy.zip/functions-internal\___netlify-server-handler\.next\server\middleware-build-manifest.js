globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/e0da1f82cbb70a74.js",
    "static/chunks/236f7e5abd6f09ff.js",
    "static/chunks/906f8aef39325416.js",
    "static/chunks/7f3db8265035b27f.js",
    "static/chunks/turbopack-d88c47a096803650.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];