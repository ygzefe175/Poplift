var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/pixel/route.js")
R.c("server/chunks/[externals]_next_dist_a6d89067._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/node_modules_next_dist_esm_build_templates_app-route_3d2d6005.js")
R.c("server/chunks/_next-internal_server_app_api_pixel_route_actions_ed9211ce.js")
R.m(42458)
module.exports=R.m(42458).exports
