module.exports=[22549,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_popups_%5BuserId%5D_route_actions_a8949601.js.map