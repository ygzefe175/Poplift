module.exports=[13057,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_supabase-test_page_actions_a44c78ab.js.map