module.exports=[18168,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_pixel_route_actions_ed9211ce.js.map