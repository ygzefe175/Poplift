module.exports=[66647,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_track_route_actions_2f4b0913.js.map