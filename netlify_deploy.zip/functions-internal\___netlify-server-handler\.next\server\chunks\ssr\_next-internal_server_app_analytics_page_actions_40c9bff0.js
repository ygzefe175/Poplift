module.exports=[92151,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_analytics_page_actions_40c9bff0.js.map