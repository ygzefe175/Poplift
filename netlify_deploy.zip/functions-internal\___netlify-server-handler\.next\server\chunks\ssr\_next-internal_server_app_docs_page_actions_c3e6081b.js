module.exports=[92810,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_docs_page_actions_c3e6081b.js.map