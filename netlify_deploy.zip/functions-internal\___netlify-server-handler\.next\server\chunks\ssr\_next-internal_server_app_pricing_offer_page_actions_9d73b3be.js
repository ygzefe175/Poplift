module.exports=[6360,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_pricing_offer_page_actions_9d73b3be.js.map