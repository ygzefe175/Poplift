var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/track/route.js")
R.c("server/chunks/[root-of-the-server]__31f93f12._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_669a44bf._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_next-internal_server_app_api_track_route_actions_2f4b0913.js")
R.m(98083)
module.exports=R.m(98083).exports
