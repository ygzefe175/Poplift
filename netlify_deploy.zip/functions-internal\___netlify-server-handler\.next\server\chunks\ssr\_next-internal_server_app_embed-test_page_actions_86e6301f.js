module.exports=[45935,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_embed-test_page_actions_86e6301f.js.map