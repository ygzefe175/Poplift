module.exports=[16809,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_kvkk_page_actions_647b22a2.js.map