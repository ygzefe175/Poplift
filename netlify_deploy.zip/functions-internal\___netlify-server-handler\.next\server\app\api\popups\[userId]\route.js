var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/popups/[userId]/route.js")
R.c("server/chunks/[root-of-the-server]__c5c01d25._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_669a44bf._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_next-internal_server_app_api_popups_[userId]_route_actions_a8949601.js")
R.m(15330)
module.exports=R.m(15330).exports
